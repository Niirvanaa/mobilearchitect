package com.zybooks.myapp_najahthompson;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    /* Defining the UI elements and the database helper */
    private EditText usernameEntry, passwordEntry;
    private Button loginBtn, registerBtn;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Ensure this matches your XML file name

        /* Initializing the database helper and UI components */
        dbHelper = new DatabaseHelper(this);
        usernameEntry = findViewById(R.id.username);
        passwordEntry = findViewById(R.id.password);
        loginBtn = findViewById(R.id.btnLogin);
        registerBtn = findViewById(R.id.createLoginButton);

        /* Logic for the Login Button */
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = usernameEntry.getText().toString();
                String pass = passwordEntry.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please enter all fields", Toast.LENGTH_SHORT).show();
                } else {
                    /* Check the database for matching credentials */
                    boolean isLogged = dbHelper.checkUser(user, pass);
                    if (isLogged) {
                        Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                        /* Move to the next screen (the Data Grid) */
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(LoginActivity.this, "Invalid Credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        /* Logic for the Register Button (New User) */
        registerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = usernameEntry.getText().toString();
                String pass = passwordEntry.getText().toString();

                if (user.equals("") || pass.equals("")) {
                    Toast.makeText(LoginActivity.this, "Please enter all fields to register", Toast.LENGTH_SHORT).show();
                } else {
                    /* Attempt to add a new user to the database */
                    boolean isInserted = dbHelper.addUser(user, pass);
                    if (isInserted) {
                        Toast.makeText(LoginActivity.this, "Registered Successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
